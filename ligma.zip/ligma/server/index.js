const config = {
    db: {
        host:'localhost',
        user: 'root',
        password: ' ',
        database: 'test'
    }
}